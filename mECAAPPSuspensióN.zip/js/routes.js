angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('temas.mecaApp', {
    url: '/page1',
    views: {
      'side-menu21': {
        templateUrl: 'templates/mecaApp.html',
        controller: 'mecaAppCtrl'
      }
    }
  })

  .state('temas', {
    url: '/side-menu21',
    templateUrl: 'templates/temas.html',
    controller: 'temasCtrl'
  })

  .state('temas.sistemaDeFrenos', {
    url: '/page2',
    views: {
      'side-menu21': {
        templateUrl: 'templates/sistemaDeFrenos.html',
        controller: 'sistemaDeFrenosCtrl'
      }
    }
  })

  .state('temas.sistemaDeSuspensiN', {
    url: '/page4',
    views: {
      'side-menu21': {
        templateUrl: 'templates/sistemaDeSuspensiN.html',
        controller: 'sistemaDeSuspensiNCtrl'
      }
    }
  })

  .state('temas.cualidadesSistemaDeSuspensN', {
    url: '/page5',
    views: {
      'side-menu21': {
        templateUrl: 'templates/cualidadesSistemaDeSuspensN.html',
        controller: 'cualidadesSistemaDeSuspensNCtrl'
      }
    }
  })

  .state('temas.elementosBSicosDelSistemaDeSuspensiN', {
    url: '/page6',
    views: {
      'side-menu21': {
        templateUrl: 'templates/elementosBSicosDelSistemaDeSuspensiN.html',
        controller: 'elementosBSicosDelSistemaDeSuspensiNCtrl'
      }
    }
  })

  .state('temas.muellesPorHojas', {
    url: '/muellesPorHojas',
    views: {
      'side-menu21': {
        templateUrl: 'templates/muellesPorHojas.html',
        controller: 'muellesPorHojasCtrl'
      }
    }
  })

  .state('temas.tiposDeSistemasDeSuspensiN', {
    url: '/page9',
    views: {
      'side-menu21': {
        templateUrl: 'templates/tiposDeSistemasDeSuspensiN.html',
        controller: 'tiposDeSistemasDeSuspensiNCtrl'
      }
    }
  })

  .state('temas.acercaDeMecaApp', {
    url: '/page10',
    views: {
      'side-menu21': {
        templateUrl: 'templates/acercaDeMecaApp.html',
        controller: 'acercaDeMecaAppCtrl'
      }
    }
  })

  .state('temas.tiposDeSuspensiNRGida', {
    url: '/page11',
    views: {
      'side-menu21': {
        templateUrl: 'templates/tiposDeSuspensiNRGida.html',
        controller: 'tiposDeSuspensiNRGidaCtrl'
      }
    }
  })

  .state('temas.tiposDeSuspensiNIndependiente', {
    url: '/page12',
    views: {
      'side-menu21': {
        templateUrl: 'templates/tiposDeSuspensiNIndependiente.html',
        controller: 'tiposDeSuspensiNIndependienteCtrl'
      }
    }
  })

  .state('temas.muellesEspirales', {
    url: '/muellesEspirales',
    views: {
      'side-menu21': {
        templateUrl: 'templates/muellesEspirales.html',
        controller: 'muellesEspiralesCtrl'
      }
    }
  })

  .state('temas.barraDeTorsiN', {
    url: '/BarraDeTorsion',
    views: {
      'side-menu21': {
        templateUrl: 'templates/barraDeTorsiN.html',
        controller: 'barraDeTorsiNCtrl'
      }
    }
  })

  .state('amortiguador', {
    url: '/Amortiguadores',
    templateUrl: 'templates/amortiguador.html',
    controller: 'amortiguadorCtrl'
  })

$urlRouterProvider.otherwise('/side-menu21/page1')


});